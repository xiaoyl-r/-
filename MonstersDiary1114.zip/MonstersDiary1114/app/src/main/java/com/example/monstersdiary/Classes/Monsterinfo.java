package com.example.monstersdiary.Classes;

public class Monsterinfo {
    private String Mname; //怪兽名
    private String stage; //怪兽等级
    private String gender; //怪兽性别
    private  int Mpoints;//怪兽积分
    private String Mfeature;//怪兽性格

    public Monsterinfo() {
    }

    public Monsterinfo(String Mname, String stage, String gender, int Mpoints, String Mfeature) {
        this.Mname = Mname;
        this.stage = stage;
        this.gender = gender;
        this.Mpoints = Mpoints;
        this.Mfeature = Mfeature;
    }

    public int getMpoints() {
        return Mpoints;
    }

    public void setMpoints(int Mpoints) {
        this.Mpoints = Mpoints;
    }

    public String getMname() {
        return Mname;
    }

    public void setMname(String Mname) {
        this.Mname = Mname;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getGender() { return gender; }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMfeature(){return Mfeature;}

    public void setMfeature(String Mfeature){this.Mfeature = Mfeature;}
}

