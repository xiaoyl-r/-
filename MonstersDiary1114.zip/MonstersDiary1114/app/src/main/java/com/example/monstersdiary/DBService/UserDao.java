package com.example.monstersdiary.DBService;


import com.example.monstersdiary.Classes.Userinfo;

import java.util.ArrayList;
import java.util.List;

public class UserDao extends DbOpenHelper {
    //查询所有用户信息
    public List<Userinfo> getAllUserList() {
        List<Userinfo> list = new ArrayList<>();
        try {
            getConnection();  //取得连接信息
            String sql = "select * from user";
            pStmt = conn.prepareStatement(sql);
            rs = pStmt.executeQuery();
            while (rs.next()) {
                Userinfo item = new Userinfo();
                item.setUname(rs.getString("username"));
                item.setUpass(rs.getString("password"));
                item.setMonster_name(rs.getString("monster_name"));
                list.add(item);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            closeAll();
        }
        return list;
    }

    //按学号查询
    public Userinfo getByUname(String uname) {
        Userinfo item = null;
        try {
            getConnection();  //取得连接信息
            String sql = "select * from user where username=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, uname);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                item = new Userinfo();
                item.setUname(rs.getString("username"));
                item.setUpass(rs.getString("password"));
                item.setMonster_name(rs.getString("monster_name"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            closeAll();
        }
        return item;
    }

    //按用户名和密码进行查询
    public Userinfo getUnameAndUpass(String uname, String upass) {
        Userinfo item = null;
        try {
            getConnection();  //取得连接信息
            String sql = "select * from user where username=? and password=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, uname);
            pStmt.setString(2, upass);
            rs = pStmt.executeQuery();
            if (rs.next()) {
                item = new Userinfo();
                item.setUname(uname);
                item.setUpass(upass);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            closeAll();
        }
        return item;
    }

    //添加用户信息
    public int addUser(Userinfo item) {
        int iRow = 0;
        try {
            getConnection();  //取得连接信息
            String sql = "insert into user(username, password) values(?, ?)";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, item.getUname());
            pStmt.setString(2, item.getUpass());
            iRow = pStmt.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            closeAll();
        }
        return iRow;
    }

    //修改用户信息
    public int editUser(Userinfo item) {
        int iRow = 0;
        try {
            getConnection();  //取得连接信息
            String sql = "update user_stu set password=? where sno=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, item.getUpass());
            pStmt.setString(2, item.getUname());
            iRow = pStmt.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            closeAll();
        }
        return iRow;
    }
}
