package com.example.monstersdiary.Classes;

import java.io.Serializable;

//用户信息实体类
public class Userinfo implements Serializable {
    private String uname; //用户名
    private String upass; //用户密码
    private String monster_name;//用户的怪兽

    public Userinfo() {
    }

    public Userinfo(String uname, String upass, String monster_name) {
        this.uname = uname;
        this.upass = upass;
        this.monster_name = monster_name;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUpass() {
        return upass;
    }

    public void setUpass(String upass) {
        this.upass = upass;
    }

    public String getMonster_name(){return monster_name;}

    public void setMonster_name(String monster_name){this.monster_name = monster_name;}

}
