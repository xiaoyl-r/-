package com.example.monstersdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.monstersdiary.Classes.Userinfo;
import com.example.monstersdiary.DBService.UserDao;
import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private GifImageView btn_login;
    private Handler mainhandler;  //主线程
    private UserDao userDao;  //数据库连接操作类

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.home_username);
        password = findViewById(R.id.home_password);
        btn_login = findViewById(R.id.home_login);

        userDao = new UserDao();
        mainhandler = new Handler(getMainLooper()); //获取主线程

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doLogin();
            }
        });

    }

    //执行登陆操作
    public void doLogin() {
        final String uname = username.getText().toString().trim();
        final String upass = password.getText().toString().trim();

        if (TextUtils.isEmpty(uname)) {
            Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
            username.requestFocus();
        } else if (TextUtils.isEmpty(upass)) {
            Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
            password.requestFocus();
        } else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Userinfo item = userDao.getUnameAndUpass(uname, upass);
                    mainhandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (item == null) {
                                Toast.makeText(MainActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent intent = new Intent(MainActivity.this, HomePage.class);
                                startActivity(intent);
                            }
                        }
                    });
                }
            }).start();
        }
    }
}